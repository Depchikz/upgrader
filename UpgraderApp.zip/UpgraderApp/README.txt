Вариант 1 (Android Studio): File > Open > эта папка > Build > Build APK(s).
Вариант 2 (без установки): залей папку в новый репозиторий GitHub -> вкладка Actions -> Build APK -> скачай app-debug.apk из Artifacts.
